
// Superclase Formas
public abstract class Formas {
    protected String color;

    public Formas(String color) {
        this.color = color;
    }

    public void establecerColor(String color) {
        this.color = color;
    }

    public abstract void dibujar();
}
